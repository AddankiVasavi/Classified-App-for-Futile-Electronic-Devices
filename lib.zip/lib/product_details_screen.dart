import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class details extends StatefulWidget {
  final String product;
  final String phonenumber;
  final String imageUrl;
  final String Address;
  final String Price;


  details({
    required this.imageUrl,
    //required this.documentSnapshot,
    required this.Address,
    required this.product,
    required this.phonenumber,
    required this.Price,
  });
  @override
  _details createState() => _details();
}

class _details extends State<details> {

  @override
   String phone="";
  _makingPhoneCall(String phone) async {
    var url = Uri.parse(phone);
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  Widget build(BuildContext context) {

     return Scaffold(
      appBar: AppBar(
        title:Text("Product Details"),
        elevation: 0,
        backgroundColor: Colors.green,
        leading:
        IconButton(onPressed: () {
          Navigator.pop(context);
        }, icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black,)),
      ),

      body: Container(

        child: Container(


          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 12),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(0),
                          bottomRight: Radius.circular(0),
                          topLeft: Radius.circular(8),
                          topRight: Radius.circular(8),
                        ),
                        child: Image.network(
                          widget.imageUrl,
                          width: 500,
                          height: 300,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 4, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          widget.product,
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          'Rs.${widget.Price}',
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          widget.phonenumber,
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          widget.Address,
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          'Note:Please Contact the seller\nthrough given mobile number',
                          style: TextStyle(fontSize: 25,color:Colors.red),

                        ),

                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8, 100, 8, 8),

                  child: MaterialButton(
                    minWidth: 200,
                    height:60,
                    //color: Colors.indigoAccent[400],
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)
                    ),
                    child: Text('CALL', style: TextStyle(fontSize: 20.0),),
                    color: Colors.green,
                    textColor: Colors.white,
                    onPressed: () {
                      setState(() {
                        phone="tel:"+widget.phonenumber;
                      });
                      _makingPhoneCall(phone);
                    },
                  ),
                ),



              ],
            ),
          ),


        ),




      ),

    );
  }
  }