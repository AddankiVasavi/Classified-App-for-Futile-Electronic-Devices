import 'package:flutter/material.dart';
import 'mysellrequests.dart';
import 'selling.dart';
import 'Buying.dart';

class homepage extends StatelessWidget{
  const homepage();
   @override
   Widget build(BuildContext context) {

     return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        title:Text("Home Page"),
        backgroundColor: Colors.green,


      ),

    body: Center(child: Column(children: <Widget>[

      SizedBox(height: 40),
      SizedBox(height: 40),
      SizedBox(height: 40),
      SizedBox(height: 40),
      SizedBox(height: 40),
    Container(
    margin: EdgeInsets.all(25),
    child: MaterialButton(
      minWidth: double.infinity,
      height:60,
      //color: Colors.indigoAccent[400],
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(40)
      ),
    child: Text('BUYING', style: TextStyle(fontSize: 20.0),),
      color: Colors.green,
      textColor: Colors.white,
    onPressed: () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) =>  Buying()),
      );
    },
    ),
    ),
    Container(
    margin: EdgeInsets.all(25),

    child: MaterialButton(
      minWidth: double.infinity,
      height:60,

      //color: Colors.indigoAccent[400],
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(40)
      ),
    child: Text('SELLING', style: TextStyle(fontSize: 20.0),),
    color: Colors.green,
    textColor: Colors.white,
    onPressed: () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const MyApp1()),
      );
    },
    ),
    ),
      Container(
        margin: EdgeInsets.all(25),
        child: MaterialButton(
          minWidth: double.infinity,
          height:60,
          //color: Colors.indigoAccent[400],
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(40)
          ),
          child: Text('MY REQUESTS', style: TextStyle(fontSize: 20.0),),
          color: Colors.green,
          textColor: Colors.white,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) =>  requests()),
            );
          },
        ),
      ),
    ]
    ),
    ),

    );

  }
}
