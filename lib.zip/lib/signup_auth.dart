import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class FireAuth {

  static String message="";
  static Future<User?> registerUsingEmailPassword( {
    required String email,
    required String password,
  }) async {
    FirebaseAuth auth = FirebaseAuth.instance;
    User? user;
    try {
      UserCredential userCredential = await auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      user = userCredential.user;

      //await user!.updateProfile(displayName: name);
      await user?.reload();
      user = auth.currentUser;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
        Fluttertoast.showToast(
            msg: 'The password provided is too weak.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER
            ,

            backgroundColor: Colors.white,
            textColor: Colors.red
        );



      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
        message='email-already-in-use';
        Fluttertoast.showToast(
            msg: 'email-already-in-use',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER
            ,

            backgroundColor: Colors.white,
            textColor: Colors.red
        );



      }
    } catch (e) {
      print(e);
      Fluttertoast.showToast(
          msg:"please check your details",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER
          ,

          backgroundColor: Colors.white,
          textColor: Colors.red
      );
    }
    Fluttertoast.showToast(
        msg: 'account created',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER
        ,

        backgroundColor: Colors.white,
        textColor: Colors.red
    );
    return user;

  }
  static Future<User?> signInUsingEmailPassword({
    required String email,
    required String password,
    //required BuildContext context,
  }) async {
    FirebaseAuth auth = FirebaseAuth.instance;
    User? user;

    try {
      UserCredential userCredential = await auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      user = userCredential.user;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        print('No user found for that email.');
        Fluttertoast.showToast(
            msg: 'No user found for that email.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER
            ,

            backgroundColor: Colors.white,
            textColor: Colors.red
        );
      } else if (e.code == 'wrong-password') {
        print('Wrong password provided.');
        Fluttertoast.showToast(
            msg: 'Wrong password provided.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER
            ,

            backgroundColor: Colors.white,
            textColor: Colors.red
        );
      }
    }


    return user;
  }
  static Future<Future> showYesNoAlertDialog({
    required BuildContext context,
    required String titleText,
    required String messageText,
  }) async {
    // set up the buttons
    final Widget yesButton = MaterialButton(
      onPressed: () => Navigator.pop(context, 'yes'),
      child: const Text('Yes'),
    );
    final Widget noButton = MaterialButton(
      onPressed: () => Navigator.pop(context, 'no'),
      child: const Text('No'),
    );

    // set up the AlertDialog
    final alert = AlertDialog(
      title: Text(titleText),
      content: Text(messageText),
      actions: [
        yesButton,
        noButton,
      ],
    );

    // show the dialog
    return showDialog(
      context: context,
      builder: (context) => alert,
    );
  }




}


