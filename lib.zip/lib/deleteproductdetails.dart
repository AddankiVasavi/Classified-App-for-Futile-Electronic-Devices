import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'mysellrequests.dart';
class deletedetails extends StatefulWidget {
  final String product;
  final String phonenumber;
  final String imageUrl;
  final String Address;
  final String Price;


  deletedetails({
    required this.imageUrl,
    //required this.documentSnapshot,
    required this.Address,
    required this.product,
    required this.phonenumber,
    required this.Price,
  });
  @override
  _details createState() => _details();
}

class _details extends State<deletedetails> {
  String? docid="";
  @override
  bool addeddata=true;
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text("Product Details"),
        elevation: 0,
        backgroundColor: Colors.green,
        leading:
        IconButton(onPressed: () {
          Navigator.pop(context);
        }, icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black,)),
      ),

      body: Container(

        child: Container(


          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 12),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(0),
                          bottomRight: Radius.circular(0),
                          topLeft: Radius.circular(8),
                          topRight: Radius.circular(8),
                        ),
                        child: Image.network(
                          widget.imageUrl,
                          width: 500,
                          height: 300,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 4, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          widget.product,
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          '\$${widget.Price}',
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          '\$${widget.phonenumber}',
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 2, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(8, 4, 0, 0),
                        child: Text(
                          '\$${widget.Address}',
                          style: TextStyle(fontSize: 25),

                        ),
                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8, 100, 8, 8),

                  child: MaterialButton(
                    minWidth: 200,
                    height:60,
                    //color: Colors.indigoAccent[400],
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)
                    ),
                    child: Text('DELETE', style: TextStyle(fontSize: 20.0),),
                    color: Colors.green,
                    textColor: Colors.white,
                    onPressed: () {
                      if(addeddata){
                        Fluttertoast.showToast(
                            msg: 'please wait until data is deleted',
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.CENTER
                            ,

                            backgroundColor: Colors.red,
                            textColor: Colors.white
                        );
                      }

                      FirebaseFirestore.instance
                          .collection('users')
                          .where('imageUrl', isEqualTo: widget.imageUrl)
                          .get()
                          .then((value) {
                        value.docs.forEach((element) {
                          print(element.id);
                          setState(() {
                            docid=element.id;
                          });
                        });
                      });
                      FirebaseFirestore.instance.collection('users').doc(docid).delete();
                      Reference photoRef = FirebaseStorage.instance.refFromURL(widget.imageUrl);
                      photoRef.delete().then((value) {
                        print('deleted Successfully');
                      });


                      setState(() {
                        addeddata=false;
                      });

                      Fluttertoast.showToast(
                          msg: 'request cancelled',
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER
                          ,

                          backgroundColor: Colors.white,
                          textColor: Colors.green
                      );
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const requests()),
                      );

                    },
                  ),
                ),



              ],
            ),
          ),


        ),




      ),

    );
  }
}