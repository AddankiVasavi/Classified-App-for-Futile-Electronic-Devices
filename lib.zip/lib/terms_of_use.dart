import 'package:flutter/material.dart';

class TermsOfUseScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Terms of Use'),
      ),
      body: SingleChildScrollView(
      child: Padding(
    padding: const EdgeInsets.all(16.0),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    'Terms of Use',
    style: TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    ),
    ),
      Text(
        'Welcome to rEwaste!',
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'These Terms of Use govern your use of our mobile application and any related services provided by rewaste app. By accessing or using the App, you agree to comply with these Terms of Use. Please read them carefully before using the App.',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '1. Acceptance of Terms',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'By using the App, you affirm that you are at least 18 years old and capable of entering into a binding legal agreement. If you are using the App on behalf of an organization, you represent and warrant that you have the necessary authority to bind the organization to these Terms of Use.',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '2. Applicability',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'These Terms of Use apply to all users of the App, including registered '
            'and unregistered users. Certain features and functionalities of the App '
            'may be subject to additional terms and conditions, which will be presented to you when you'
            ' access those features.',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bol,
        ),
      ),
      Text(
        '3. User Accounts',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'Some features of the App may require you to create a user account. '
            'You are responsible for maintaining the confidentiality of your account credentials and for any activities that occur under your account. You must promptly notify us of any unauthorized use or suspected breach of security. We reserve the '
            'right to suspend or terminate your account at our discretion.',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '4. User Content',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'The App may allow you to submit, post, or transmit content, '
            'such as product image,Address,and other contact Information. '
            'You retain ownership of your User Content, but by submitting it, you grant us a non-exclusive, worldwide, royalty-free license to use, reproduce, modify, adapt, publish, translate, distribute, and display your User Content in connection with the App. You represent '
            'and warrant that you have all necessary rights to grant this license.',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '5. Prohibited Conduct',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'You agree not to engage in any of the following prohibited activities while using the App:',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '- Violating any applicable laws or regulations\n- Infringing upon the rights of others',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '- Uploading, posting, or transmitting any harmful, defamatory, obscene, or otherwise objectionable content \n- Interfering with or disrupting the operation of the App',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        '  - Impersonating any person or entity, or falsely representing your '
            'affiliation with any person or entity\n- Engaging in any '
            'unauthorized advertising, promotional, or commercial activities',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),
          Text(
            '6. Intellectual Property',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            'The App and its contents, including but not limited to text, '
                'graphics, logos, images, and software, are the property of rEwaste and '
                'are protected by intellectual property laws. You may not modify, reproduce, distribute, or create '
                'derivative works based on the App without our prior written consent.',
            style: TextStyle(
              fontSize: 15,
              //fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            '7. Disclaimer of Warranties',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
      Text(
        'The App is provided on an "as is" and "as available" basis, '
            'without any warranties of any kind, whether express or implied. '
            'We do not warrant that the App will be uninterrupted, error-free, or secure, or '
            'that any defects will be corrected. '
            'Your use of the App is at your own risk.',
        style: TextStyle(
        fontSize: 15,
       // fontWeight: FontWeight.bold,
      ),
    ),

      Text(
        '8. Modifications and Termination',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
      Text(
        'We reserve the right to modify, suspend, or terminate '
            'the App or these Terms of Use at any time, with or without notice. '
            'We may also impose limits on certain features or restrict '
            'your access to parts or all of the App without liability or prior notice.',
        style: TextStyle(
          fontSize: 15,
          //fontWeight: FontWeight.bold,
        ),
      ),

    ]
    ),
    ),
      )
    );
  }
}