import 'package:flutter/material.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'homepage.dart';
import 'signup.dart';
import 'signup_auth.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}



//void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
   MyApp() ;

  static const String _title = 'Sample App';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: _title,
      home: Scaffold(

        body:  LoginPage(),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
   LoginPage();


  @override
  State<LoginPage> createState() => _LoginPage();
}
class _LoginPage extends State<LoginPage> {




  @override

  Widget build(BuildContext context) {
    //CollectionReference users = FirebaseFirestore.instance.collection('users');
    final _emailTextController = TextEditingController();
    final _passwordTextController = TextEditingController();


    final _focusEmail = FocusNode();
    final _focusPassword = FocusNode();
    //Future<void> addStudent() {
      // Calling the collection to add a new user
      //return users
      //adding to firebase collection
          //.add({
        //Data added in the form of a dictionary into the document.
        //'name': 'Addanki'
      //})
          //.then((value) => print("Student data Added"))
          //.catchError((error) => print("Student couldn't be added."));
   // }

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.green,
        title:Text("Login Page"),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,

        width: double.infinity,

        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Column(
              children: [
                Column(
                  children: [
                    Text ("Login", style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),),
                    SizedBox(height: 20,),
                    Text("Welcome back ! Login with your credentials",style: TextStyle(
                      fontSize: 15,
                      color: Colors.grey[700],
                    ),),
                    SizedBox(height: 30,)
                  ],
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: 40
                  ),
                  child: Column(
                    children: [
                      //makeInput(label: "Email"),
                      //makeInput(label: "Password",obsureText: true),
                      TextFormField(
                        controller: _emailTextController,
                        focusNode: _focusEmail,
                        decoration: InputDecoration(
                          hintText: "Email",
                          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.grey,
                            ),
                          ),
                          border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey)
                          ),
                        ),
                      ),
                      SizedBox(height: 30),
                      TextFormField(
                        controller: _passwordTextController,
                        focusNode: _focusPassword,
                        obscureText: true,

                        decoration: InputDecoration(
                          hintText: "Password",
                          //errorBorder: UnderlineInputBorder(
                          // borderRadius: BorderRadius.circular(6.0),
                          // borderSide: BorderSide(
                          //color: Colors.red,
                          //),
                          //),
                          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.grey,
                            ),
                          ),
                          border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey)
                          ),

                        ),

                      ),
                      SizedBox(height: 30,)
                    ],
                  ),

                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40),
                  child: Container(
                    padding: EdgeInsets.only(top: 3,left: 3),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        border: Border(
                            bottom: BorderSide(color: Colors.black),
                            top: BorderSide(color: Colors.black),
                            right: BorderSide(color: Colors.black),
                            left: BorderSide(color: Colors.black)
                        )
                    ),
                    child: MaterialButton (
                      minWidth: double.infinity,
                      height:60,
                      onPressed: () async {
                        Fluttertoast.showToast(
                            msg: 'Please wait a while while we navigate',
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.CENTER
                            ,

                            backgroundColor: Colors.white,
                            textColor: Colors.green
                        );
    User? user= await FireAuth.signInUsingEmailPassword(email:_emailTextController.text,password:_passwordTextController.text);

    if(user!=null)
     {
      Navigator.push(

        context,
        MaterialPageRoute(
            builder: (context) =>  homepage()),
      );
    }


                        //Navigator.push(

                          //context,
                          //MaterialPageRoute(builder: (context) => const homepage()),
                        //);
                      },
                      color: Colors.green,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40)
                      ),
                      child: Text("Login",style: TextStyle(
                          fontWeight: FontWeight.w600,fontSize: 16,color: Colors.white70
                      ),),
                    ),
                  ),
                ),
                SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Dont have an account?"),
                    TextButton(
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.green, // Text Color
                      ),
                      child: const Text(
                        'Sign up',
                        style: TextStyle(fontSize: 20),
                      ),
                      onPressed: () {
                        //signup screen
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  SignupPage()),
                        );
                      },
                    )


                  ],
                )
              ],

            ),
          ],
        ),
      ),
    );
  }
}

Widget makeInput({label,obsureText = false}){
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label,style:TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w400,
          color: Colors.black87
      ),),
      SizedBox(height: 5,),
      TextField(
        obscureText: obsureText,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Colors.grey,
            ),
          ),
          border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey)
          ),
        ),
      ),
      SizedBox(height: 30,)

    ],
  );
}
