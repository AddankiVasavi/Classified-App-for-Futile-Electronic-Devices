import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
//import 'displaydetails.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'mysellrequests.dart';
void main() { runApp(  MyApp1()); }

class MyApp1 extends StatelessWidget {
  const MyApp1();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.green,
        ),
        home: selling()
    );
  }
}

class selling extends StatefulWidget {
  const selling({super.key});




  @override
  State<selling> createState() => _selling();
}

class _selling extends State<selling> {
  CollectionReference users = FirebaseFirestore.instance.collection('users');
  final _firebaseStorage = FirebaseStorage.instance;
  // final User? user = FirebaseAuth.instance.currentUser;
  final User? user = FirebaseAuth.instance.currentUser;


   File? image;
  String? imageUrl;
  File? imageTemp;
  bool addeddata=true;





  Future pickImage() async {
    try {
      XFile? selected = await ImagePicker().pickImage(source: ImageSource.gallery);
      setState(() {
        image=File(selected!.path);
      });


    } on PlatformException catch(e) {
      print('Failed to pick image: $e');
    }
  }
  Future camera() async {
    try {
      XFile? selected = await ImagePicker().pickImage(source: ImageSource.camera);
      setState(() {
        image=File(selected!.path);
      });

    } on PlatformException catch(e) {
      print('Failed to pick image: $e');
    }
  }
  String _uid="";
  String product="";
  String city="";
  String value="";
  String price="";
  final _phonenumberController = TextEditingController();



  final _phonenumber = FocusNode();
  final _priceController = TextEditingController();



  final _price = FocusNode();


  @override
  Widget build(BuildContext context) {





    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.green,
        title:Text("product details"),

      ),
    body: Container(
    height: MediaQuery.of(context).size.height,
    width: double.infinity,
    child: Column(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Column(
    children: [

    Padding(
    padding: EdgeInsets.symmetric(
    horizontal: 40
    ),
    child: Column(
    children: [
    //makeInput(label: "Phone NUmber",obsureText: true),

      //makeInput(label: "Product Category"),
      //makeInput(label: "Address"),
      TextFormField(
        controller: _phonenumberController,
        focusNode: _phonenumber,
        decoration: InputDecoration(
          hintText: "phone number",
          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Colors.green, width: 2
            ),
          ),
          border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey)
          ),
        ),
      ),
      SizedBox(height: 30),
      Padding(
        padding: EdgeInsets.all(5.0),
        child:DropdownButtonFormField(
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder( //<-- SEE HERE
              borderSide: BorderSide(color: Colors.green, width: 2),
            ),
            focusedBorder: OutlineInputBorder( //<-- SEE HERE
              borderSide: BorderSide(color: Colors.green, width: 2),
            ),
            filled: true,
            fillColor: Colors.white,
          ),
          style: const TextStyle(
            color: Colors.blue,),
          items: [
            DropdownMenuItem<String>(
              value: "mobile",
              child: Center(
                child:Text("mobile"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "laptop",
              child: Center(
                child:Text("laptop"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "refrigerator",
              child: Center(
                child:Text("refrigerator"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "mouse",
              child: Center(
                child:Text("mouse"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "printer",
              child: Center(
                child:Text("printer"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Tab",
              child: Center(
                child:Text("Tab"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "keyboard",
              child: Center(
                child:Text("Keyboard"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "tv",
              child: Center(
                child:Text("tv"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "ac",
              child: Center(
                child:Text("ac"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "computer",
              child: Center(
                child:Text("computer"),
              ),
            )
          ],
          //onChanged: (_d)=>valuechanged(_d),
          onChanged: (String? newValue) {
            setState(() {
              product = newValue!;
            });
          },
          hint: Text(
              style: const TextStyle(
                color: Colors.grey,),
              "Select Product"//value
          ),

        ),
      ),
      SizedBox(height: 30),

      TextFormField(
        controller: _priceController,
        focusNode: _price,
        decoration: InputDecoration(
          hintText: "Expected price",
          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Colors.green, width: 2
            ),
          ),
          border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.green)
          ),
        ),
      ),
      SizedBox(height: 30),
      Padding(
        padding: EdgeInsets.all(5.0),
        child:DropdownButtonFormField(
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder( //<-- SEE HERE
              borderSide: BorderSide(color: Colors.green, width: 2),
            ),
            focusedBorder: OutlineInputBorder( //<-- SEE HERE
              borderSide: BorderSide(color: Colors.green, width: 2),
            ),
            filled: true,
            fillColor: Colors.white,
          ),
          style: const TextStyle(
            color: Colors.blue,),
          items: [


            DropdownMenuItem<String>(
              value: "Autonagar",
              child: Center(
                child:Text("Autonagar"),
              ),
            ),




              DropdownMenuItem<String>(
                value: "Bandar Road",
                child: Center(
                  child:Text("Bandar Road"),
                ),

            ),
            DropdownMenuItem<String>(
              value: "Benz Circle",
              child: Center(
                child:Text("Benz Circle"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Bhavanipuram",
              child: Center(
                child:Text("Bhavanipuram"),
              ),
            ),
                DropdownMenuItem<String>(
                value: "Chalasani nagar",
            child: Center(
            child:Text("Chalasani nagar"),
      )

            ),
            DropdownMenuItem<String>(
              value: "Enikepadu",
              child: Center(
                child:Text("Enikepadu"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "governerpet",
              child: Center(
                child:Text("governerpet"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Gunadala",
              child: Center(
                child:Text("Gunadala"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "kamayyathopu",
              child: Center(
                child:Text("Kamayyathopu"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Kanuru",
              child: Center(
                child:Text("Kanuru"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "KrishnaLanka",
              child: Center(
                child:Text("KrishnaLanka"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Moghalrajpuram",
              child: Center(
                child:Text("Moghalrajpuram"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Nidamanuru",
              child: Center(
                child:Text("Nidamanuru"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "patamata",
              child: Center(
                child:Text("patamata"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "penamaluru",
              child: Center(
                child:Text("penamaluru"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Poranki",
              child: Center(
                child:Text("Poranki"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Ramavarappudu",
              child: Center(
                child:Text("Ramavarappudu"),
              ),
            ),
            DropdownMenuItem<String>(
              value: "Satyanarayanapuram",
              child: Center(
                child:Text("Satyanarayanapuram"),
              ),
            ),
        DropdownMenuItem<String>(
            value: "Tadigadapa",
            child: Center(
              child:Text("Tadigadapa"),
            ),
        ),



          ],
          //onChanged: (_d)=>valuechanged(_d),
          onChanged: (String? newValue) {
            setState(() {
              city = newValue!;

            });
          },
          hint: Text(
              style: const TextStyle(
                color: Colors.grey,),
              "Select Address"//value
          ),

        ),
      ),
      SizedBox(height: 30),
        //print(city);





      MaterialButton(
          color: Colors.green,
          child: const Text(
              "Pick Image from Gallery",
              style: TextStyle(
                  color: Colors.white70, fontWeight: FontWeight.bold
              )
          ),
          onPressed: () {

            pickImage();
          }

      ),
      Text("or",style: TextStyle(
        fontSize: 15,
        color: Colors.grey[700],
      ),),
      MaterialButton(
          color: Colors.green,
          child: const Text(
              "Pick Image from Camera",
              style: TextStyle(
                  color: Colors.white70, fontWeight: FontWeight.bold
              )
          ),
          onPressed: () {
            camera();

          }
      ),

    ],
    ),
    ),
      SizedBox(height: 30),
    Padding(
    padding: EdgeInsets.symmetric(horizontal: 40),
    child: Container(
    padding: EdgeInsets.only(top: 3,left: 3),
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(40),
    border: Border(
    bottom: BorderSide(color: Colors.black),
    top: BorderSide(color: Colors.black),
    right: BorderSide(color: Colors.black),
    left: BorderSide(color: Colors.black)
    )
    ),


      child: MaterialButton(
        minWidth: double.infinity,
        height:60,
        onPressed: () async {
          //print(city);
          //print(product);

          try {

            if (image != null) {
              //return;
              final imageTemp = File(image!.path);
              setState(() => this.image = imageTemp);
              if(addeddata){
                Fluttertoast.showToast(
                    msg: 'please wait until data is uploaded',
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.CENTER
                    ,

                    backgroundColor: Colors.red,
                    textColor: Colors.white
                );
              }

              var snapshot = await _firebaseStorage.ref()
                  .child('userimages').child(DateTime.now().toString() + '.jpg')
                  .putFile(imageTemp); //.onComplete;
              var downloadUrl = await snapshot.ref.getDownloadURL();
              setState(() {
                imageUrl = downloadUrl;
              });

              if(user!=null){
                _uid=user!.uid;
              }

              users.add({
                'phone number': _phonenumberController.text,
                'product': product,
                'Address': city,
                'imageUrl': imageUrl,
                'price': _priceController.text,
                'uid'  :_uid,
              });
              setState(() {
                addeddata=false;

              });

            }

            else {
              print("No Image selected");
              Fluttertoast.showToast(
                  msg: 'No Image selected',
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.CENTER
                  ,

                  backgroundColor: Colors.red,
                  textColor: Colors.white
              );
            }
          }on PlatformException catch(e) {
            print('Failed to pick image: $e');
          }


          Fluttertoast.showToast(
              msg: 'request has been sent',
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER
              ,

              backgroundColor: Colors.green,
              textColor: Colors.white
          );
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const requests()),
          );

        },
        color: Colors.green,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(40)
        ),
        child: Text("Request For Sell",style: TextStyle(
            fontWeight: FontWeight.w600,fontSize: 16,color: Colors.white
        ),),
      ),
    ),
    ),
      ]
    ),
      ]

    ),
    )

    );




  }
}
Widget makeInput({label,obsureText = false}){
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label,style:TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w400,
          color: Colors.black87
      ),),
      SizedBox(height: 5,),
      TextField(
        obscureText: obsureText,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Colors.grey,
            ),
          ),
          border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey)
          ),
        ),
      ),
      SizedBox(height: 8,)

    ],
  );
}