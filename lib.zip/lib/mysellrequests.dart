

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'productionItem.dart';
import 'deleteproduct.dart';
class requests extends StatefulWidget {
  const requests({super.key});




  @override
  State<requests> createState() => _requests();
}

class _requests extends State<requests> {


  final User? user = FirebaseAuth.instance.currentUser;

  Future<QuerySnapshot>? documentslist;
  String productname=" ";


  initsearchingproduct(String uid) {
    documentslist = FirebaseFirestore.instance.collection('users').where(
        'uid', isEqualTo: uid).get();
    setState(() {
      documentslist;
    });
  }





  @override
  void initState() {
    // TODO: implement initState
    super.initState();




    final String uid = user!.uid;
    initsearchingproduct(uid);

  }

  Widget build(BuildContext context) {
    return Scaffold(

        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.green,
          title:Text("My Requests"),





        ),




        body:FutureBuilder<QuerySnapshot>(
          future:documentslist,


          builder: (context, AsyncSnapshot snapshot) {
            return !snapshot.hasData
                ? Text('Please Wait')
                : ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {

                return deleteProductItem(
                  phonenumber: snapshot.data!.docs[index]['phone number'],
                  imageUrl: snapshot.data!.docs[index]['imageUrl'],
                  product: snapshot.data!.docs[index]['product'],
                  Address: snapshot.data!.docs[index]['Address'],
                  Price:snapshot.data!.docs[index]['price'],


                );
              },

            );
          },
        )

    );
  }

}