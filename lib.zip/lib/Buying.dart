import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'productionItem.dart';
import 'productsearch..dart';

class Buying extends StatefulWidget {
  const Buying({super.key});




  @override
  State<Buying> createState() => _Buying();
}

class _Buying extends State<Buying> {
  Future<QuerySnapshot>? documentslist;
  String productname=" ";
  initsearchingproduct(String textEntered){
    documentslist=FirebaseFirestore.instance.collection('users').where('product',isGreaterThanOrEqualTo: textEntered).get();
    setState(() {
      documentslist;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading:
          IconButton(onPressed: () {
            Navigator.pop(context);
          }, icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black,)),

          title: TextField(
            onChanged: (textEntered){
              setState(() {
                productname=textEntered;
              });
              initsearchingproduct(textEntered);
              Navigator.push(

                context,
                MaterialPageRoute(
                    builder: (context) => const Product()),
              );
            },
            decoration: InputDecoration(
              hintText: 'search for a product',
            hintStyle: TextStyle(color:Colors.white),
          ),
          ),
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              onPressed: () {


                Navigator.push(

                  context,
                  MaterialPageRoute(
                      builder: (context) => const Product()),
                );
              },
              icon: const Icon(Icons.search,color:Colors.white),
            )
          ],
          centerTitle: true,
          backgroundColor: Colors.green,
        ),
      body:StreamBuilder<QuerySnapshot>(
        stream:FirebaseFirestore.instance.collection('users').snapshots(),


          builder: (context, AsyncSnapshot snapshot) {
    return !snapshot.hasData
    ? Text('Please Wait')
        : ListView.builder(
    itemCount: snapshot.data!.docs.length,
    itemBuilder: (context, index) {

      return ProductItem(
        phonenumber: snapshot.data!.docs[index]['phone number'],
        imageUrl: snapshot.data!.docs[index]['imageUrl'],
        product: snapshot.data!.docs[index]['product'],
        Address: snapshot.data!.docs[index]['Address'],
        Price:snapshot.data!.docs[index]['price'],

      );
    },

    );
    },
      )


    );
  }

}

