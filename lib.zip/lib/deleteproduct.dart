import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:firestoredatabase/operations.dart';
import 'package:flutter/material.dart';
import 'product_details_screen.dart';
import 'deleteproductdetails.dart';


class deleteProductItem extends StatefulWidget {
  final String product;
  final String phonenumber;
  final String imageUrl;
  final String Address;
  final String Price;


  deleteProductItem({
    required this.imageUrl,
    //required this.documentSnapshot,
    required this.Address,
    required this.product,
    required this.phonenumber,
    required this.Price,
  });

  @override
  _ProductItemState createState() => _ProductItemState();
}

class _ProductItemState extends State<deleteProductItem> {
  @override
  Widget build(BuildContext context) {
    return Padding(

      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: double.infinity,
        child: Row(
          children: <Widget>[
            Container(
              height: 100,
              width: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  widget.imageUrl,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Column(
                    children: <Widget>[

                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(
                          " ${widget.product}",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                              fontSize: 25),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(" ${widget.Price}",
                            style:
                            TextStyle(color: Colors.green, fontSize: 20)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(" ${widget.phonenumber}",
                            style:
                            TextStyle(color: Colors.green, fontSize: 20)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(" ${widget.Address}",
                            style:
                            TextStyle(color: Colors.green, fontSize: 20)),
                      )
                    ],
                    crossAxisAlignment: CrossAxisAlignment.start,
                  ),
                  Row(
                    children: <Widget>[

                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) =>  deletedetails(imageUrl:widget.imageUrl,Address:widget.Address,product:widget.product,phonenumber:widget.phonenumber,Price:widget.Price)),
                          );

                        },
                        icon: Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
        ),
      ),
    );
  }
}