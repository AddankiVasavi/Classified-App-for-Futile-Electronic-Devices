import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'login.dart';
import 'homepage.dart';
import 'signup_auth.dart';
import 'privacy_policy_screen.dart';
import 'terms_of_use.dart';
class SignupPage extends StatefulWidget {
  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _emailTextController = TextEditingController();
  final _passwordTextController = TextEditingController();
  final _confirmTextController = TextEditingController();
  bool? _isTermsAccepted = false;
  final _focusEmail = FocusNode();
  final _focusPassword = FocusNode();
  final _confirmPassword = FocusNode();
  void onTapPrivacyPolicy() {
    // Implement the navigation logic here
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => PrivacyPolicyScreen()),
    );
  }

  // Callback for navigating to the terms of use screen
  void onTapTermsOfUse() {
    // Implement the navigation logic here
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TermsOfUseScreen()),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        title: Text("Sign Up page"),
        backgroundColor: Colors.green,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [

                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(height: 20,),
                        Text ("Sign up", style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),),
                        SizedBox(height: 20,),
                        Text("Create an Account,Its free",style: TextStyle(
                          fontSize: 15,
                          color: Colors.grey[700],
                        ),),
                        SizedBox(height: 30,)
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: 40
                      ),
                      child: Column(
                        children: [
                          //makeInput(label: "Email"),
                          //makeInput(label: "Password",obsureText: true),
                          //makeInput(label: "Confirm Pasword",obsureText: true),
                          TextFormField(
                            controller: _emailTextController,
                            focusNode: _focusEmail,
                            decoration: InputDecoration(
                              hintText: "Email",
                              contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.grey,
                                ),
                              ),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey)
                              ),
                            ),
                          ),
                          SizedBox(height: 30),
                          TextFormField(
                            controller: _passwordTextController,
                            focusNode: _focusPassword,
                            obscureText: true,

                            decoration: InputDecoration(
                              hintText: "Password",
                              //errorBorder: UnderlineInputBorder(
                              // borderRadius: BorderRadius.circular(6.0),
                              // borderSide: BorderSide(
                              //color: Colors.red,
                              //),
                              //),
                              contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.grey,
                                ),
                              ),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey)
                              ),

                            ),

                          ),
                          SizedBox(height: 30),

                          TextFormField(
                            controller: _confirmTextController,
                            focusNode: _confirmPassword,
                            obscureText: true,

                            decoration: InputDecoration(
                              hintText: "confirm password",
                              //errorBorder: UnderlineInputBorder(
                              // borderRadius: BorderRadius.circular(6.0),
                              // borderSide: BorderSide(
                              //color: Colors.red,
                              //),
                              //),
                              contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 10),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.grey,
                                ),
                              ),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey)
                              ),

                            ),

                          ),
                          SizedBox(height: 30),
                        ],
                      ),
                    ),

                    // Checkbox for accepting terms and conditions
                    CheckboxListTile(
                      title: Text(
                        'I accept the terms of use',
                        style: TextStyle(fontSize: 14),
                      ),
                      value: _isTermsAccepted,
                      onChanged: (bool? value) {
                        setState(() {
                          _isTermsAccepted = value;
                        });
                      },
                      controlAffinity: ListTileControlAffinity.leading,
                    ),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      child: Container(
                        padding: EdgeInsets.only(top: 3, left: 3),

                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            border: Border(
                                bottom: BorderSide(color: Colors.black),
                                top: BorderSide(color: Colors.black),
                                right: BorderSide(color: Colors.black),
                                left: BorderSide(color: Colors.black)
                            )
                        ),
                        child: MaterialButton(
                          minWidth: double.infinity,
                          height:60,
                          onPressed: () {
                            if (_emailTextController.text != "" &&
                                _passwordTextController.text != "" &&
                                _confirmTextController.text != "") {
                              if (_passwordTextController.text ==
                                  _confirmTextController.text) {
                                FireAuth.registerUsingEmailPassword(
                                    email: _emailTextController.text,
                                    password: _passwordTextController.text);
                                if (_isTermsAccepted == true) {
                                  Fluttertoast.showToast(
                                      msg: 'account created',
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.CENTER
                                      ,

                                      backgroundColor: Colors.green,
                                      textColor: Colors.white
                                  );
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => const homepage()),
                                  );
                                }
                                else {
                                  Fluttertoast.showToast(
                                      msg: 'please accept the terms and conditions',
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.CENTER
                                      ,

                                      backgroundColor: Colors.white,
                                      textColor: Colors.red
                                  );
                                }
                              }
                              else {
                                print("please check your password");
                                Fluttertoast.showToast(
                                    msg: 'please check your password',
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.CENTER
                                    ,

                                    backgroundColor: Colors.white,
                                    textColor: Colors.red
                                );
                              }
                            }
                            else{
                              Fluttertoast.showToast(
                                  msg: 'fields are empty',
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.CENTER
                                  ,

                                  backgroundColor: Colors.white,
                                  textColor: Colors.red
                              );
                            }



                          },
                          color: Colors.green,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40)
                          ),
                          child: Text("Sign Up",style: TextStyle(
                            fontWeight: FontWeight.w600,fontSize: 16,

                          ),),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40),
            child: RichText(
              textAlign: TextAlign.center,
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'By signing up, you agree to our ',
                    style: TextStyle(fontSize: 14, color: Colors.black),
                  ),

                  TextSpan(
                    text: 'terms of use',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.blue,
                      decoration: TextDecoration.underline,
                    ),
                    recognizer: TapGestureRecognizer()
                      ..onTap = onTapTermsOfUse,
                  ),
                ],
              ),
            ),
          ),

                    SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Already have an account? "),
                        TextButton(
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.green,
                          ),
                          child: const Text(
                            'Sign in',
                            style: TextStyle(fontSize: 20),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => LoginPage()),
                            );
                          },
                        )
                      ],
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}