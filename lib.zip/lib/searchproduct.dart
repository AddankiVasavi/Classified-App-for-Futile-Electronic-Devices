import 'package:firebase_storage/firebase_storage.dart';
class Users{
  String? product;
  String? price;
  String? imageUrl;
  String? phonenumber;
  String? Address;
  Users(
  {
    this.product,
    this.price,
    this.imageUrl,
    this.phonenumber,
    this.Address,
}
      );
}